import { NgModule } from '@angular/core';
//import { Routes, RouterModule } from '@angular/router';

//Lazy LOADING
import { RouterModule, Route, PreloadAllModules } from '@angular/router'; //
import { WelcomeComponent } from './welcome/welcome.component';
/*
 * moveremos al módulo de productos todos los componentes, pipes,
 * directivas, etc. que tengan que ver con productos y que ahora mismo se declaran en
 * el módulo de la aplicación.
 */

import { EventosShowComponent } from './eventos/eventos-show/eventos-show.component';
import { EventosFilterPipe } from './eventos/pipes/eventos-filter.pipe';
import { EventoItemComponent } from './eventos/evento-item/evento-item.component';
import { EventoAddComponent } from './eventos/evento-add/evento-add.component';
import { EventoDetailComponent } from './eventos/evento-detail/evento-detail.component';
import { EventoDetailResolve } from './eventos/resolvers/evento-detail.service';

import { BaseUrlInterceptor } from './eventos/interceptors/base-url.interceptor';
import { AuthTokenInterceptor } from './eventos/interceptors/auth-token.interceptor';
import { SaveChangesGuard } from './eventos/guards/save-changes.guard';

import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { EventosModule } from './eventos/eventos.module';
import { CommonModule } from '@angular/common';

// Lo traigo aquí y cambio APP_ROUTES por routes
const APP_ROUTES: Route[] = [
  { path: 'welcome', component: WelcomeComponent },
  {
    path: 'eventos',
    loadChildren: () =>
      import('./eventos/eventos.module').then((m) => m.EventosModule),
  },
  { path: '', redirectTo: '/welcome', pathMatch: 'full' },
  { path: '**', redirectTo: '/welcome', pathMatch: 'full' },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(APP_ROUTES, { preloadingStrategy: PreloadAllModules }),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: BaseUrlInterceptor,
      multi: true,
    },
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
