import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EventosShowComponent } from './eventos-show/eventos-show.component';
import { EventosFilterPipe } from './pipes/eventos-filter.pipe';
import { EventoItemComponent } from './evento-item/evento-item.component';
import { EventoAddComponent } from './evento-add/evento-add.component';
import { EventoDetailComponent } from './evento-detail/evento-detail.component';
import { EventoDetailResolve } from './resolvers/evento-detail.service';
import { SaveChangesGuard } from './guards/save-changes.guard';

const routes: Routes = [
  { path: 'eventos', component: EventosShowComponent },
  {
    path: 'eventos/add',
    component: EventoAddComponent,
    canDeactivate: [SaveChangesGuard],
  },
  {
    path: 'eventos/:id',
    component: EventoDetailComponent,
    resolve: {
      evento: EventoDetailResolve,
    },
  },
  { path: '', redirectTo: '/eventos', pathMatch: 'full' },
  { path: '**', redirectTo: '/eventos', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EventosRoutingModule {}
