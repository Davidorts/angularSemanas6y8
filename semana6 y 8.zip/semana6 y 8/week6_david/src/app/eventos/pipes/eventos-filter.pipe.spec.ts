import { EventosFilterPipe } from './eventos-filter.pipe';

describe('EventosFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new EventosFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
