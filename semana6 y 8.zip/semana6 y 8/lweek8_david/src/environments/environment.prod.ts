export const environment = {
  production: true,
  baseUrl: 'http://localhost:8080'
  // baseUrl: 'http://arturober.com:5004'
};
