import { SameValueDirective } from './same-value.directive';

describe('SameValueDirective', () => {
  it('should create an instance', () => {
    const directive = new SameValueDirective();
    expect(directive).toBeTruthy();
  });
});
