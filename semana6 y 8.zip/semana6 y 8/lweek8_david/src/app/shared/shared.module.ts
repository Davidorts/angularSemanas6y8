import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MinDateDirective } from './validators/min-date.directive';
import { SameValueDirective } from './validators/same-value.directive';
import { ConfirmModalComponent } from './confirm-modal/confirm-modal.component';

@NgModule({
  declarations: [
    MinDateDirective,
    SameValueDirective,
    ConfirmModalComponent
  ],
  imports: [
    CommonModule
  ],
  entryComponents: [
    ConfirmModalComponent
    ],
  exports: [
    MinDateDirective,
    SameValueDirective,
    ConfirmModalComponent,
  ]
})
export class SharedModule { }
