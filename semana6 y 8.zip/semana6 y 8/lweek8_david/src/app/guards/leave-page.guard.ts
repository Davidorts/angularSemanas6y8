import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  CanDeactivate,
} from '@angular/router';
import { Observable } from 'rxjs';
import { EventoAddComponent } from '../eventos/evento-add/evento-add.component';

@Injectable({
  providedIn: 'root',
})
export class LeavePageGuard implements CanActivate, CanDeactivate {
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    return true;
  }

  // Añado el guard CanDeactivate para controlar la salida de la pagina
  canDeactivate(
    component: EventoAddComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
    ): boolean | UrlTree {
    // Recibimos el componente por parámetro → podemos acceder sus métodos
    return confirm('¿Quieres abandonar la página?. Los cambios no se guardarán.');
    }
}
