import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Evento } from '../interfaces/evento';
import { EventosService } from '../services/eventos.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmModalComponent } from 'src/app/shared/confirm-modal/confirm-modal.component';

@Component({
  selector: 'evento-item',
  templateUrl: './evento-item.component.html',
  styleUrls: ['./evento-item.component.css']
})
export class EventoItemComponent implements OnInit {
  @Input() evento: Evento;
  @Output() deleted = new EventEmitter<void>();
  private modalService: NgbModal;


  constructor(private eventosService: EventosService) { }

  ngOnInit(): void {
  }

  deleteEvento() {
    this.eventosService.deleteEvento(this.evento.id).subscribe(
      () => this.deleted.emit(),
      error => console.error(error)
    );
  }

  // Añado el canDeactivate. Además debo suscribirme al evento
  canDeactivate(): Promise<boolean> {
    const modalRef = this.modalService.open(ConfirmModalComponent);
    modalRef.componentInstance.title = 'Eliminar producto';
    modalRef.componentInstance.body = '¿Está seguro de eliminar el producto?';
    return modalRef.result // Cuando cerramos con close → Promise<boolean>
    .catch(() => false); // dismiss → Promise<false>;
  }
}
