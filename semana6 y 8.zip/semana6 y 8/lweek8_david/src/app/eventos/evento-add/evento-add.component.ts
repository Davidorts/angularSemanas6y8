import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Evento } from '../interfaces/evento';
import { EventosService } from '../services/eventos.service';
import { CanDeactivate, Router } from '@angular/router';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { NgModel } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmModalComponent } from '../../shared/confirm-modal/confirm-modal.component';
import { SaveChangesGuard } from 'src/app/guards/save-changes.guard';
//import { CanDeactivate } from 'src/app/guards/save-changes.guard';

@Component({
  selector: 'evento-add',
  templateUrl: './evento-add.component.html',
  styleUrls: ['./evento-add.component.css']
})
export class EventoAddComponent implements OnInit {
  newEvento: Evento;
  @Output() add = new EventEmitter<Evento>();
  saved = false;
  fechaHoy = new Date().toISOString();
  private modalService: NgbModal;

  constructor(private eventosService: EventosService, private router: Router) { }

  ngOnInit(): void {
    this.resetFormulario();
  }

  canDeactivate(): Promise<boolean> {
    const modalRef = this.modalService.open(ConfirmModalComponent);
    modalRef.componentInstance.title = 'Modificar producto';
    modalRef.componentInstance.body = 'Los cambios no se guardarán. ¿Desea salir?';
    return modalRef.result // Cuando cerramos con close → Promise<boolean>
    .catch(() => false); // dismiss → Promise<false>;
  }

  addEvento() {
    this.eventosService.addEvento(this.newEvento).subscribe(
      evento => {
        this.saved = true;
        this.router.navigate(['/eventos']);
      }
    );
  }

  resetFormulario() {
    this.newEvento = {
      name: '',
      description: '',
      image: '',
      price: null,
      date: ''
    };
  }

  changeImage(fileInput: HTMLInputElement) {
    if (!fileInput.files || fileInput.files.length === 0) { return; }
    const reader: FileReader = new FileReader();
    reader.readAsDataURL(fileInput.files[0]);
    reader.addEventListener('loadend', e => {
      this.newEvento.image = reader.result as string;
    });
  }

  validClasses(ngModel: NgModel, validClass: string, errorClass: string) {
    return {
      [validClass]: ngModel.touched && ngModel.valid,
      [errorClass]: ngModel.touched && ngModel.invalid
    };
  }

}
