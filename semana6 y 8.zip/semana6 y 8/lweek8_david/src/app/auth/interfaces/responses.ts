export interface LoginResponse {
  expires: number;
  accessToken: string;
}
